package com.example.spinner

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
