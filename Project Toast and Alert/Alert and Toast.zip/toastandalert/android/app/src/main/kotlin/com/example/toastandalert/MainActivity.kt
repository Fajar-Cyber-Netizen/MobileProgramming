package com.example.toastandalert

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
