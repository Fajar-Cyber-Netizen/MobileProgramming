package com.example.grafik

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
