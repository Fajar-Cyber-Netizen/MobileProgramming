package com.example.loginregister

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
