package com.example.thread

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
